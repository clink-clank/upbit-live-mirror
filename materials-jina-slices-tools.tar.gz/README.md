# materials-jina-slices-tools

두 스크립트로 80KB 슬라이스를 만들어 Jina 프록시로 배포하고, 원격에서 재조립할 수 있습니다.

## 파일
- `bin/jina_slices_publish.sh` : `web/docs/materials_current.b64gz.txt`를 80KB씩 잘라 `web/docs/jina_slices/<tag>/`에 업로드(+manifest.json 작성, git push).
- `bin/jina_fetch_and_join.sh` : 매니페스트(Jina URL)를 받아 슬라이스를 합치고 base64+gz 복호화 → JSON을 출력.

## 배치 경로
레포 루트(예: `~/upbit-live-mirror`)에 압축 해제하면 `bin/` 이하가 생성됩니다.

## 설치/권한
```bash
cd ~/upbit-live-mirror
unzip materials-jina-slices-tools.zip
chmod +x bin/jina_slices_publish.sh bin/jina_fetch_and_join.sh
```

## 사용법
### 1) 슬라이스 게시
```bash
# 기본 입력 파일과 태그 사용
bin/jina_slices_publish.sh

# 또는 입력/태그 지정
bin/jina_slices_publish.sh web/docs/materials_current.b64gz.txt materials_current
```

실행 후 콘솔에 **Manifest (branch/pinned)** Jina URL이 출력됩니다.

### 2) 원격 재조립
```bash
bin/jina_fetch_and_join.sh "https://r.jina.ai/https://raw.githubusercontent.com/<owner>/<repo>/<commit 또는 refs/heads/main>/web/docs/jina_slices/materials_current/manifest.json"
```

정상 시 3줄 요약이 나오고, 완전 JSON 경로가 마지막에 표시됩니다.
